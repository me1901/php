<!DOCTYPE html>
<html>
<head>
    <title>Games</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    
</body>
</html>
<?php
    include_once("../function.php");
    $login = $_COOKIE["login"];
    echo "hello, $login<br>";
    echo "<a href = '../edit.php'>edit</a>";
    echo "<ul>";
    $db = connect();
    $i = 1;
    while(true){
        $query = "
            SELECT `game_name` FROM `games`
            WHERE `game_id` = $i;
            ";
        $result = mysqli_query($db, $query);
        $name = mysqli_fetch_assoc($result);
        $name = $name["game_name"];
        echo "
            <li> <a href = '../chats/$name.php'>$name</a>
        ";
        $i++;
    }
    echo "</ul>";
?>