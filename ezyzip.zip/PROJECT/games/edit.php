<!DOCTYPE html>
<html>
<head>
    <title>edit</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <label>login</label>
        <input type="text" name = "login"><br>
        <label>email</label>
        <input type="email" name = "email"><br>
        <label>password</label>
        <input type="text" name = "pass"><br>
        <label>new</label>
        <input type = "text" name = "pass_repeat">
        <br>
        <label>avatar</label>
        <input type="file" name="avatar">
        <br>
        <input type="submit">
    </form>
</body>
</html>
<?php
    include_once('../function.php');
    $db = connect();
    $login = $_COOKIE['login'];
    $query = "
        SELECT `user_id`, `user_name`, `user_password` FROM `users`
        WHERE `user_name` = '$login';
                    ";
        $result = mysqli_query($db, $query);
        $arr = mysqli_fetch_assoc($result);
    if(isset($_POST['login'])){
        $newlogin = $_POST['login'];
        $newemail = $_POST['email'];
        $pass = $_POST['pass'];
        $pass_repeat = $_POST['pass_repeat'];
        
        if ($pass !== $arr["user_password"]) {
            echo 'wrong password';
        } else {
            if (!mysqli_errno($db)) {
                $hash_pass = md5($pass_repeat);
                $query = "
                    INSERT INTO `users`
                    SET `user_login` = '$login',
                        `user_email` = '$email',
                        `user_password` = '$hash_pass';
                    ";
                    $result = mysqli_query($db, $query);
                    
                    $user_id = mysqli_insert_id($db);
                    $token = generateToken();
                    $token_time = time() + 15*60;
                    setcookie('token_time', $token_time, time() + 2*24*60*60);
                    setcookie('token', $token, time() + 2*24*60*60);
                    setcookie('user_id', $user_id, time() + 2*24*60*60);
                    setcookie('user_name', $login, time() + 2*24*60*60);
                    mysqli_close($db);
                   // header('Location: ../books/books.php');
            }
        }
    }
?>