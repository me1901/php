<!DOCTYPE html>
<html>
<head>
    <title>Authorisation</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <label>login</label>
        <input type="text" name = "login"><br>
        <label>password</label>
        <input type="text" name = "pass"><br>
        <input type="submit">
    </form>
</body>
</html>
<?php
    include_once('../function.php');
    if(isset($_POST['login'])){
        $login = $_POST['login'];
        $pass = $_POST['pass'];
            $db = connect();
            if (!mysqli_errno($db)) {
                $hash_pass = md5($pass)
                $query = "
                SELECT `user_id`, `user_name` FROM `users`
                WHERE `user_name` = '$login'
				AND `user_password` = '$hash_pass';
                    ";
                    $result = mysqli_query($db, $query);
                    
                    $user_id = mysqli_insert_id($db);
                    $token = generateToken();
                    $token_time = time() + 15*60;
                    setcookie('token_time', $token_time, time() + 2*24*60*60);
                    setcookie('token', $token, time() + 2*24*60*60);
                    setcookie('user_id', $user_id, time() + 2*24*60*60);
                    setcookie('user_name', $login, time() + 2*24*60*60);
                    mysqli_close($db);
                   // header('Location: ../books/books.php');
        }
    }
?>