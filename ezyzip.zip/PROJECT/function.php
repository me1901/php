<?php

function view($template, $data = [])
{
    if (file_exists($template)) {
        extract($data);
        include($template);
    } else {
        exit('Страница не существует');
    }
}

function connect(){
    $connect = mysqli_connect('localhost', 'root', '', 'database');
    mysqli_set_charset($connect, 'utf8');
    if (mysqli_connect_errno()) {
        die('ошибка подключения к базе данных');
    }
    return $connect;
}

function generateToken($size = 32){
	$symbols = ['0', '1', '2', '3', '4','5','6', '7', '8', '9', 'a', 'b', 'c', 'd'];
	$lenght = count($symbols) - 1;
	$token = '';
	for ($i = 0; $i < $size; $i++) {
		$token .= $symbols[rand(0, $lenght)];
	}
	return $token;
}
function addGame($db, $game_name){
    $query = "
        CREATE TABLE `$game_name"."_messages` (
        `message_id` int(10) UNSIGNED NOT NULL,
        `message_val` varchar(10000) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
    ";
    mysqli_query($db, $query);
}

function writeMes($db, $game_name, $message){
    if(strlen($message)>10000){
        die("too big message");
    }
    $query = "
        INSERT INTO `connects`
        SET `message` = '$message';
    ";
    mysqli_query($db, $query);
}
?>