<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../style.css">
    <title>Document</title>
</head>
<body>
    <form method="post">
        <label>message</label>
        <input type="text" name = "message">
        <input type="submit">
    </form>
    <?php
        $i = 1;
        while(true){
            $query = "
            SELECT `message_val`, `user_id` FROM `сумерки империи_messages`
            WHERE `game_id` = $i;
            ";
            $result = mysqli_query($db, $query);
            $arr = mysqli_fetch_assoc($result);
            $val = $arr["game_name"];
            echo "
                <p> $val </p>
            ";
            echo "<br>";
            $i++;
        }
    ?>
</body>
</html>
<?php
    if(isset($_POST["message"])){
        $query = "
        INSERT INTO `сумерки империи_messages` (`message_val`) VALUES (".$_POST["message"].")"
    }
?>