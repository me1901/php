<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../style.css">
    <title>Document</title>
</head>
<body>
    <form method="post">
        <label>message</label>
        <input type="text" name = "message">
        <input type="submit">
    </form>

</body>
</html>